﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maze_game
{
    internal class ClassEnemy
    {
        public ClassCords cords= new ClassCords();
        public char symbol = '&';
        public ConsoleColor color = ConsoleColor.Red;

        public ClassEnemy() { }
        public ClassEnemy(ClassCords cords)
        {
            this.cords = cords;
        }
    }
}
