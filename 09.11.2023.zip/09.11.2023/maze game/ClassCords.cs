﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maze_game
{
    internal class ClassCords
    {
        public int Column;
        public int Row;
        public ClassCords() { }
        public ClassCords(int column, int row)
        {
            Column = column;
            Row = row;
        }
    }
}
