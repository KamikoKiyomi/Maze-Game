﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace maze_game
{
    /*hra maze game - Krpec Lukáč 2023
       @ - hráč
       $ - coin system
       X - past
       & - enemy
       E - Exit pro další level

       levely jsou náhodně stvořené a objekty inicializované s nahodnou lokací v 2d arrayi a navyšujícími parametry s předem nastavenou předlovou
       
       verze: 09.11.2023
       
       Patch notes:
       *Added menu
       *Balance enemies
       *debug Exit
     */
    internal class Program
    {
        //klasické nastavení různých obejktů pro změnu obtížností
        static int moneyCount = 3;
        static char moneySymbol = '$';
        static ConsoleColor moneyColor = ConsoleColor.Green;

        static int trapsCount = 0;
        static char trapSymbol = 'X';
        static int trapsMaxCount = 4;
        static ConsoleColor trapColor = ConsoleColor.Red;

        static int enemyCount = 0;
        static int enemyMaxCount = 4;
        static List<ClassEnemy> enemiesList = new List<ClassEnemy>();

        static int wallCount = 5;

        static int health = 3;
        static int coins = 0;
        static int CompletedLevels = 0;

        static char ColorText(char text, ConsoleColor color)
        {
            Console.ForegroundColor = color; // Set the text color
            char coloredText = text;
            return coloredText;
            //!! vždy po použití funkce použít resetcolor();
        }

        static char[,] GenerateMaze()
        {
            //random generator mazes s inicializací objektů a enemies
            
            char[,] maskMaze = {

            {'#','#','#','#','#','#','#','#','#','#','#','#','#','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#','#','#','#','#','#','#','#','#','#','#','#','#','#'},

            };

            char[,] testMask = new char[maskMaze.GetLength(0), maskMaze.GetLength(1)];

            for (int i = 0; i < maskMaze.GetLength(0); i++)
            {
                for (int j = 0; j < maskMaze.GetLength(1); j++)
                {
                    testMask[i, j] = maskMaze[i, j];
                }
            }

            enemiesList.Clear();
            int emptySpace = 0;
            List<ClassCords> emptySpaceCords = new List<ClassCords>();
            List<ClassCords> wallCords = new List<ClassCords>();
            
            for (int i = 0;i<testMask.GetLength(0);i++)
            {
                for(int j = 0;j<testMask.GetLength(1);j++)
                {
                    //spočíta počet objektů v masce
                    //najde souřadnice objektů v masce
                    if (testMask[i, j] == ' ')
                    {
                        emptySpace++;
                        emptySpaceCords.Add(new ClassCords(i,j));
                    }
                       

                    if (testMask[i,j] == '#')
                    {
                        wallCords.Add(new ClassCords(i,j));
                    }
                       
                }   
            }
            Random rand = new Random();
            for (int i = 0; i < moneyCount; i++)
            {
                //vygeneruje nahodně coiny do mapy
                int result = rand.Next(0, emptySpaceCords.Count);
                testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] = moneySymbol;
                emptySpaceCords.RemoveAt(result);
            }
            for(int i = 0; i < wallCount; i++)
            {
                int result = rand.Next(0,wallCords.Count);
                if (testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] != moneySymbol)
                testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] = '#';
                else
                {
                    if (i != 0)
                        i--;
                }
                emptySpaceCords.RemoveAt(result);

            }
            for (int i = 0; i < trapsCount; i++){
                int result = rand.Next(0, emptySpaceCords.Count);
                if (testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] != moneySymbol || testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] != '#' || testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] != 'E')
                    testMask[emptySpaceCords[result].Column, emptySpaceCords[result].Row] = trapSymbol;
                else
                {
                    if (i != 0)
                        i--;
                }
                emptySpaceCords.RemoveAt(result);

                if (trapsMaxCount == i)
                    break;
            }

            List<ClassCords> exitCords = new List<ClassCords>();
            int exitPositionIndex = -1;
            while (exitPositionIndex == -1 || testMask[emptySpaceCords[exitPositionIndex].Column, emptySpaceCords[exitPositionIndex].Row] != ' ')
            {
                exitPositionIndex = rand.Next(0, emptySpaceCords.Count);
            }
            testMask[emptySpaceCords[exitPositionIndex].Column, emptySpaceCords[exitPositionIndex].Row] = 'E';
            emptySpaceCords.RemoveAt(exitPositionIndex);

            for (int i = 0; i < enemyCount; i++)
            {
                int result = rand.Next(0,emptySpaceCords.Count);
                if (maskMaze[emptySpaceCords[result].Column, emptySpaceCords[result].Row] != 'E')
                {
                    enemiesList.Add(new ClassEnemy(new ClassCords(emptySpaceCords[result].Column, emptySpaceCords[result].Row)));
                    emptySpaceCords.RemoveAt(result);
                    testMask[enemiesList[i].cords.Column, enemiesList[i].cords.Row] = enemiesList[i].symbol;
                }
                if(i == enemyMaxCount)
                {
                    break;
                }

                

            }

            //debug
            bool isExit = false;
            for (int i = 0; i < maskMaze.GetLength(0); i++)
            {
                for(int j = 0; j < maskMaze.GetLength(1); j++)
                {
                    if (maskMaze[i, j] == 'E')
                        isExit = true;
                }
            }
            if (!isExit)
            {
                int result = rand.Next(0, emptySpaceCords.Count);
                maskMaze[emptySpaceCords[result].Column, emptySpaceCords[result].Row] = 'E';
            }

            trapsCount++;
            enemyCount++;
            return testMask;

        }

        static char[,] InsertCharacter(char[,] maze, char character)
        {
            //debug method
            List<ClassCords> emptyCords = new List<ClassCords>();
            for(int i = 0; i < maze.GetLength(0); i++)
            {
                for(int j = 0; j < maze.GetLength(1); j++)
                {
                    if (maze[i,j] == ' ')
                        emptyCords.Add(new ClassCords(i, j));
                }
            }

            Random rand = new Random();
            int result = rand.Next(0, emptyCords.Count);
            maze[emptyCords[result].Column, emptyCords[result].Row] = character;
            return maze;

        }

        static void Main(string[] args)
        {
            //mapy z předešlých testů jsou tu jen na debug
            /*char[,] maskMaze = {

            {'#','#','#','#','#','#','#','#','#','#','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#','@',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#','#','#','#','#','#','#','#','#','#','#'},

            };*/

            /*char[,] maze = {

            {'#','#','#','#','#','#','#','#','#','E','#'},
            {'#',' ','#',' ',' ',' ','#',' ','#',' ','#'},
            {'#',' ',' ',' ',' ',' ','#',' ',' ',' ','#'},
            {'#','#','#','#',' ','#','#',' ','#','#','#'},
            {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#',' ','#',' ','#','#','#',' ','#','#','#'},
            {'#',' ','#',' ',' ',' ',' ',' ',' ',' ','#'},
            {'#','@','#',' ',' ',' ','#',' ',' ','#','#'},
            {'#','#','#','#','#','#','#','#','#','#','#'},

            };*/

            char[,] maze = GenerateMaze();
            Random randColumn = new Random();
            Random randRow = new Random();
            maze[randColumn.Next(1, maze.GetLength(0)), randRow.Next(1, maze.GetLength(1))] = '@';

            do
            {
                Console.WriteLine("MAZE GAME".PadLeft(50));
                Console.WriteLine("Press P".PadLeft(40) + "\t  Play");
                Console.WriteLine("Press G".PadLeft(40) + "\t  Guide");
                
                ConsoleKeyInfo consoleKey = Console.ReadKey();
                if (consoleKey.Key == ConsoleKey.P)
                    break;
                else if (consoleKey.Key == ConsoleKey.G)
                {
                    Console.Clear();
                    Console.WriteLine(ColorText('@',ConsoleColor.Blue) + "\t...Player");
                    Console.ResetColor();
                    Console.WriteLine(ColorText(trapSymbol, trapColor) + "\t...Trap");
                    Console.ResetColor();
                    Console.WriteLine(ColorText(moneySymbol, moneyColor) + "\t...Coins");
                    Console.ResetColor();
                    Console.WriteLine(ColorText('&', ConsoleColor.Red) + "\t... Enemy");
                    Console.ResetColor();

                    Console.WriteLine("Player inputs: WASD | Arrow Keys\t...For movement");
                    Console.WriteLine("3 Coins == +Health");
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("invalid input... press any key to continue");
                    Console.ReadLine();
                }
                Console.Clear();
            } while (true);
            Console.Clear();
            
            

            while (true)
            {
                //player nastavení
                int playerRowIndex = 0;
                int playerColumnIndex = 0;

                for (int i = 0; i < maze.GetLength(0); i++)
                {
                    for (int j = 0; j < maze.GetLength(1); j++)
                    {
                        if (maze[i, j] == '@')
                        {
                            playerColumnIndex = i;
                            playerRowIndex = j;
                            break;
                        }
                    }
                }
                //debug
                if (playerRowIndex == 0 && playerColumnIndex == 0)
                {
                    maze = InsertCharacter(maze,'@');
                }
                bool check = false;
                for(int i = 0; i < maze.GetLength(0); i++)
                {
                    for(int j = 0; j < maze.GetLength(1); j++)
                    {
                        if (maze[i, j] == 'E')
                            check = true;
                    }
                }
                if (!check)
                    InsertCharacter(maze, 'E');
                

                //basic gui
                for (int i = 0; i < maze.GetLength(0); i++)
                {
                    for (int j = 0; j < maze.GetLength(1); j++)
                    {
                        if (maze[i, j] == '@')
                        {
                            Console.Write(ColorText('@', ConsoleColor.Blue));
                            Console.ResetColor();
                        }
                        else if (maze[i, j] == '$')
                        {
                            Console.Write(ColorText(moneySymbol, moneyColor));
                            Console.ResetColor();
                        }
                        else if (maze[i,j] == 'X')
                        {
                            Console.Write(ColorText(trapSymbol, trapColor));
                            Console.ResetColor();
                        }
                        else if (maze[i,j] == '&')
                        {
                            Console.Write(ColorText('&', ConsoleColor.Red));
                            Console.ResetColor();
                        }
                        else
                            Console.Write(maze[i, j]);
                    }
                    Console.WriteLine();
                }
                Console.WriteLine($"\nHealth: {health} | Coins: {coins} | Completed Levels: {CompletedLevels}");

                //pohyb hráče kde koliduje s různymi objekty
                ConsoleKeyInfo inputKey = Console.ReadKey();

                if(inputKey.Key == ConsoleKey.UpArrow || inputKey.Key == ConsoleKey.W)
                {
                    //up movement
                    if (maze[playerColumnIndex-1,playerRowIndex] != '#' && maze.GetLength(0) >= playerColumnIndex - 1)
                    {
                        if (maze[playerColumnIndex - 1, playerRowIndex] == '$')
                            coins++;
                        if (maze[playerColumnIndex - 1, playerRowIndex] == 'E')
                        {
                            maze = GenerateMaze();
                            CompletedLevels++;
                        }
                        if (maze[playerColumnIndex - 1, playerRowIndex] == 'X')
                        {
                            health--;
                        }

                        maze[playerColumnIndex, playerRowIndex] = ' ';
                        playerColumnIndex--;
                        maze[playerColumnIndex, playerRowIndex] = '@';
                    }
                }

                
                if (inputKey.Key == ConsoleKey.DownArrow || inputKey.Key == ConsoleKey.S)
                {
                    //down movement
                    if (maze[playerColumnIndex + 1, playerRowIndex] != '#' && maze.GetLength(0) >= playerColumnIndex + 1)
                    {
                        if (maze[playerColumnIndex + 1, playerRowIndex] == '$')
                            coins++;
                        if(maze[playerColumnIndex + 1, playerRowIndex] == 'E')
    {
                            maze = GenerateMaze();
                            CompletedLevels++;
                        }
                        if (maze[playerColumnIndex + 1, playerRowIndex] == 'X')
                        {
                            health--;
                        }


                        maze[playerColumnIndex, playerRowIndex] = ' ';
                        playerColumnIndex++;
                        maze[playerColumnIndex, playerRowIndex] = '@';
                    }
                }

                if (inputKey.Key == ConsoleKey.LeftArrow || inputKey.Key == ConsoleKey.A)
                {
                    //left movement
                    if (playerRowIndex - 1 >= 0 && maze[playerColumnIndex, playerRowIndex - 1] != '#')
                    {
                        if (maze[playerColumnIndex, playerRowIndex - 1] == '$')
                            coins++;
                        if (maze[playerColumnIndex, playerRowIndex - 1] == 'E')
                        {
                            maze = GenerateMaze();
                            CompletedLevels++;
                        }
                        if (maze[playerColumnIndex, playerRowIndex + 1] == 'X')
                        {
                            health--;
                        }

                        maze[playerColumnIndex, playerRowIndex] = ' ';
                        playerRowIndex--;
                        maze[playerColumnIndex, playerRowIndex] = '@';
                    }
                }

                if (inputKey.Key == ConsoleKey.RightArrow || inputKey.Key == ConsoleKey.D)
                {
                    //right movement
                    if (playerRowIndex + 1 < maze.GetLength(1) && maze[playerColumnIndex, playerRowIndex + 1] != '#')
                    {
                        if (maze[playerColumnIndex, playerRowIndex + 1] == '$')
                            coins++;
                        if (maze[playerColumnIndex, playerRowIndex + 1] == 'E')
                        {
                            maze = GenerateMaze();
                            CompletedLevels++;
                        }
                        if (maze[playerColumnIndex, playerRowIndex + 1] == 'X')
                        {
                            health--;
                        }

                        maze[playerColumnIndex, playerRowIndex] = ' ';
                        playerRowIndex++;
                        maze[playerColumnIndex, playerRowIndex] = '@';
                    }
                }

                

                for (int i = 0; i < enemiesList.Count; i++)
                {
                    
                    int randomMove = new Random().Next(0, 5);

                    
                    if (randomMove < 1)
                    {
                        
                        int newColumn = enemiesList[i].cords.Column;
                        int newRow = enemiesList[i].cords.Row;

                        
                        if (playerColumnIndex < enemiesList[i].cords.Column)
                        {
                            newColumn--;
                        }
                        else if (playerColumnIndex > enemiesList[i].cords.Column)
                        {
                            newColumn++;
                        }

                        if (playerRowIndex < enemiesList[i].cords.Row)
                        {
                            newRow--;
                        }
                        else if (playerRowIndex > enemiesList[i].cords.Row)
                        {
                            newRow++;
                        }

                        
                        if (maze[newColumn, newRow] == '@')
                        {
                            maze[enemiesList[i].cords.Column, enemiesList[i].cords.Row] = ' ';
                            enemiesList.RemoveAt(i);
                            health--;
                            break;
                        }

                        
                        if (newColumn >= 0 && newColumn < maze.GetLength(0) && newRow >= 0 && newRow < maze.GetLength(1) &&
                            maze[newColumn, newRow] != '#' && maze[newColumn, newRow] != 'E')
                        {
                            maze[enemiesList[i].cords.Column, enemiesList[i].cords.Row] = ' ';
                            enemiesList[i].cords.Column = newColumn;
                            enemiesList[i].cords.Row = newRow;
                            maze[enemiesList[i].cords.Column, enemiesList[i].cords.Row] = '&';
                        }
                    }
                }





                if (health == 0)
                {
                    coins = 0;
                    CompletedLevels = 0;
                    trapsCount = 0;
                    enemyCount = 0;
                    health = 3;
                }

                if(coins == 3)
                {
                    health++;
                    coins = 0;
                }
                
                Console.Clear();
            }
        }
    }
}
